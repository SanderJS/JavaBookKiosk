import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class BookTest {

    @Test
    void setAuthor() {
    }

    @Test
    void setTitle() {
    }

    @Test
    void setPublisher() {
    }

    @Test
    void setEdition() {
    }

    @Test
    void setGenre() {
    }

    @Test
    void setReleaseDate() {
    }

    @Test
    void setPages() {
    }

    @Test
    void setPrice() {
    }

    @Test
    void setSeries() {
    }

    @Test
    void setBookAsSeries() {
    }

    @Test
    void setRefNumber() {
    }

    @Test
    void setSeriesName() {
    }

    @Test
    void getRefNumber() {
    }

    @Test
    void getTitle() {
    }

    @Test
    void getPublisher() {
    }

    @Test
    void getAuthor() {
    }

    @Test
    void printDetailsAsString() {
    }
}