import static org.junit.jupiter.api.Assertions.*;

class ApplicationUITest {

    @org.junit.jupiter.api.Test
    void start() {
    }

    @org.junit.jupiter.api.Test
    void listAllProducts() {
    }
}