import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class BookStorageTest {

    @Test
    void addNewBook() {
    }

    @Test
    void addBook() {
    }

    @Test
    void removeBookFromList() {
    }

    @Test
    void getBookByAuthor() {
    }

    @Test
    void getBookByPublisher() {
    }

    @Test
    void getBookByTitleAndPublisher() {
    }

    @Test
    void listAllBooks() {
    }

    @Test
    void listSize() {
    }
}